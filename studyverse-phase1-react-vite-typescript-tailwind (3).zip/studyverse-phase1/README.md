# Studyverse — Fase 1: Experience Hub

Página inicial em React + TypeScript + Vite + Tailwind CSS v4.

## Requisitos
- Node.js 20.19+ ou 22.12+
- npm

## Instalação
```bash
npm install
npm run dev
```

## Verificação e build
```bash
npm run typecheck
npm run build
npm run preview
```

O build de produção é gerado na pasta `dist`.

## Deploy na Vercel
Importe o repositório `mariavitoriaadm04-debug/studyverse` na Vercel. Use:
- Framework Preset: Vite
- Root Directory: `./`
- Install Command: `npm install`
- Build Command: `npm run build`
- Output Directory: `dist`

A Fase 1 contém dados demonstrativos no catálogo. Integração com backend, autenticação e persistência não fazem parte desta base inicial.
